import csv, datetime as dt, json, os, re, statistics, sys
from pathlib import Path
import requests

API = "https://www.googleapis.com/youtube/v3"
OUT = Path("output")
OUT.mkdir(exist_ok=True)
KEY = os.getenv("YOUTUBE_API_KEY", "").strip()
LANG = os.getenv("LANGUAGE", "bn").strip().lower()
CHANNELS = [os.getenv(f"C{i}", "").strip() for i in range(1, 6)]
CHANNELS = [c for c in CHANNELS if c]

def api(endpoint, params):
    params["key"] = KEY
    r = requests.get(f"{API}/{endpoint}", params=params, timeout=25)
    if not r.ok:
        raise RuntimeError(f"YouTube API {endpoint} failed: {r.status_code} {r.text[:300]}")
    return r.json()

def channel_id_from_url(url):
    # Supports channel IDs and handles; custom /c/ and /user/ URLs may need manual channel ID.
    if re.search(r"youtube\.com/channel/(UC[\w-]+)", url):
        return re.search(r"youtube\.com/channel/(UC[\w-]+)", url).group(1)
    m = re.search(r"youtube\.com/@([^/?]+)", url)
    if m:
        data = api("channels", {"part":"id","forHandle":m.group(1)})
        items = data.get("items", [])
        if items: return items[0]["id"]
    m = re.search(r"youtube\.com/(?:c|user)/([^/?]+)", url)
    if m:
        data = api("search", {"part":"snippet","type":"channel","q":m.group(1),"maxResults":1})
        items = data.get("items", [])
        if items: return items[0]["snippet"]["channelId"]
    raise ValueError(f"Could not resolve channel URL: {url}. Use https://www.youtube.com/@handle or /channel/UC...")

def videos_for_channel(url):
    cid = channel_id_from_url(url)
    ch = api("channels", {"part":"snippet,contentDetails","id":cid}).get("items", [])
    if not ch: return []
    uploads = ch[0]["contentDetails"]["relatedPlaylists"]["uploads"]
    pl = api("playlistItems", {"part":"snippet,contentDetails","playlistId":uploads,"maxResults":15})
    ids = [x["contentDetails"].get("videoId") for x in pl.get("items", []) if x["contentDetails"].get("videoId")]
    if not ids: return []
    vd = api("videos", {"part":"snippet,statistics,contentDetails","id":",".join(ids)})
    now = dt.datetime.now(dt.timezone.utc)
    rows = []
    for v in vd.get("items", []):
        sn, st = v.get("snippet", {}), v.get("statistics", {})
        try: published = dt.datetime.fromisoformat(sn["publishedAt"].replace("Z","+00:00"))
        except Exception: published = now
        age_hours = max((now-published).total_seconds()/3600, 1)
        views = int(st.get("viewCount",0))
        rows.append({
          "channel_url":url, "channel_title":sn.get("channelTitle",""),
          "video_id":v["id"], "title":sn.get("title",""),
          "description":re.sub(r"\s+"," ",sn.get("description",""))[:1200],
          "published_at":sn.get("publishedAt",""), "views":views,
          "views_per_hour":round(views/age_hours,2),
          "video_url":f"https://www.youtube.com/watch?v={v['id']}"
        })
    return rows

def make_script(video):
    title = video["title"].strip()
    desc = video["description"].strip()
    if LANG == "en":
        return f"""TITLE: {title} — Explained

HOOK:
Have you ever wondered what is really happening behind this story? Today, let's break it down.

EXPLAINER DRAFT:
The topic we're exploring is: {title}.
Based on the public video title and description, this story raises several questions worth investigating. First, what is the background? Second, what evidence supports the main claims? And finally, why does it matter?

RESEARCH NOTES:
{desc or "No description was provided. Verify facts from reliable independent sources before recording."}

ENDING:
That is the key idea behind this topic. Check the sources, question bold claims, and tell us what you think.

EDITOR NOTE:
This is a structured starter draft, not a fact-checked final script. Research and verify every factual claim before publishing.
"""
    return f"""শিরোনাম: {title} — সহজ ভাষায় ব্যাখ্যা

শুরুর হুক:
এই ঘটনার পেছনে আসলে কী আছে, কখনও ভেবে দেখেছেন? চলুন, বিষয়টি সহজভাবে বুঝে নেওয়া যাক।

এক্সপ্লেনেশন ড্রাফট:
আজ আমরা যে বিষয়টি নিয়ে আলোচনা করছি, সেটি হলো—{title}।
এই বিষয়টি বুঝতে হলে প্রথমে এর পটভূমি জানতে হবে। এরপর দেখতে হবে, কোন তথ্যগুলো নির্ভরযোগ্য প্রমাণ দিয়ে সমর্থিত এবং কোন দাবিগুলো আরও যাচাই করা দরকার। সবশেষে বুঝতে হবে, বিষয়টি আমাদের কাছে কেন গুরুত্বপূর্ণ।

গবেষণার নোট:
{desc or "ভিডিওর বিবরণ পাওয়া যায়নি। রেকর্ডিংয়ের আগে নির্ভরযোগ্য স্বাধীন সূত্র থেকে তথ্য যাচাই করুন।"}

শেষ কথা:
এই ছিল বিষয়টির মূল ধারণা। প্রকাশের আগে তথ্য ও সূত্র যাচাই করুন, আর আপনার মতামত কমেন্টে জানান।

সম্পাদকের নোট:
এটি একটি প্রাথমিক স্ক্রিপ্ট ড্রাফট, সম্পূর্ণ তথ্য-যাচাইকৃত স্ক্রিপ্ট নয়। প্রতিটি তথ্য প্রকাশের আগে স্বাধীন ও নির্ভরযোগ্য সূত্র থেকে যাচাই করতে হবে।
"""

def main():
    if not KEY:
        raise RuntimeError("Missing YOUTUBE_API_KEY repository secret.")
    if len(CHANNELS) != 5:
        raise RuntimeError(f"Expected five channel URLs, got {len(CHANNELS)}. Set five inputs or CHANNEL_1..CHANNEL_5 repository variables.")
    all_rows = []
    errors = []
    for url in CHANNELS:
        try: all_rows.extend(videos_for_channel(url))
        except Exception as e: errors.append(f"{url}: {e}")
    if not all_rows:
        raise RuntimeError("No videos found. " + " | ".join(errors))
    # Rank by total views (the initial requested criterion); views/hour remains available for context.
    all_rows.sort(key=lambda x: (x["views"], x["views_per_hour"]), reverse=True)
    csv_path = OUT / "videos.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        w.writeheader(); w.writerows(all_rows)
    winner = all_rows[0]
    script = make_script(winner)
    (OUT / "TOP_PICK.txt").write_text(
      f"Selected topic: {winner['title']}\nChannel: {winner['channel_title']}\n"
      f"Views: {winner['views']}\nViews/hour (approx): {winner['views_per_hour']}\n"
      f"Video URL: {winner['video_url']}\n\n"
      f"IMPORTANT: Do not download/reuse the source video without permission or a suitable license.\n\n"
      f"{script}\n", encoding="utf-8")
    report = [
      "# YouTube Shorts Exploration Research",
      f"- Generated at (UTC): {dt.datetime.now(dt.timezone.utc).isoformat()}",
      f"- Script language: {LANG}",
      f"- Videos analyzed: {len(all_rows)}",
      "",
      "## Top candidate",
      f"- **{winner['title']}**",
      f"- Channel: {winner['channel_title']}",
      f"- Views: {winner['views']:,}",
      f"- Approx. views/hour: {winner['views_per_hour']}",
      f"- URL: {winner['video_url']}",
      "",
      "## Important",
      "This is a topic-selection signal, not permission to reuse the source footage. Verify claims using independent sources and use original narration plus footage you own or are licensed to use.",
      "",
      "## Channel errors",
      *(["- " + e for e in errors] or ["- None"])
    ]
    (OUT / "REPORT.md").write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report[:14]))
if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
