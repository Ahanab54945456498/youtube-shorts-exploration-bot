export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response(JSON.stringify({error:"Use POST"}), {status:405,headers:cors});
    try {
      const body = await request.json();
      if (!Array.isArray(body.channels) || body.channels.length !== 5 ||
          body.channels.some(x => typeof x !== "string" || !/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(x)) ||
          !["bn","en"].includes(body.language)) {
        return new Response(JSON.stringify({error:"Provide five HTTPS YouTube URLs and language bn/en"}), {status:400,headers:cors});
      }
      const owner = env.GH_OWNER, repo = env.GH_REPO, workflow = env.GH_WORKFLOW || "daily.yml";
      if (!env.GH_TOKEN || !owner || !repo) return new Response(JSON.stringify({error:"Worker secrets/variables are not configured"}),{status:500,headers:cors});
      const url = `https://api.github.com/repos/${owner}/${repo}/actions/workflows/${workflow}/dispatches`;
      const gh = await fetch(url, {
        method:"POST",
        headers:{
          "Authorization":`Bearer ${env.GH_TOKEN}`,
          "Accept":"application/vnd.github+json",
          "X-GitHub-Api-Version":"2022-11-28",
          "User-Agent":"shorts-exploration-worker",
          "Content-Type":"application/json"
        },
        body:JSON.stringify({ref:"main",inputs:{
          channel_1:body.channels[0],channel_2:body.channels[1],channel_3:body.channels[2],
          channel_4:body.channels[3],channel_5:body.channels[4],language:body.language,
          publish_time: typeof body.publish_time==="string" ? body.publish_time : "18:30"
        }})
      });
      if (!gh.ok) return new Response(JSON.stringify({error:`GitHub returned ${gh.status}. Check token permissions, branch, and workflow filename.`}),{status:502,headers:cors});
      return new Response(JSON.stringify({ok:true,url:`https://github.com/${owner}/${repo}/actions`}),{status:200,headers:cors});
    } catch (e) {
      return new Response(JSON.stringify({error:"Invalid request or upstream failure"}),{status:400,headers:cors});
    }
  }
};
